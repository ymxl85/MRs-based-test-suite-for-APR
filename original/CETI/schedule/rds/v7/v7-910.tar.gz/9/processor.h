float getOperand(char * str);

void getAdata(char * str,int *pos, char * s);
