./$1 '[^47'	'F~aM'	';#f6AX~asyf4.bm&Jy' >> $2/O1
